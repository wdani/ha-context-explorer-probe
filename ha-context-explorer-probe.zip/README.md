# HA Context Explorer Probe

A separate experimental Home Assistant custom integration with its own sidebar UI.

This is **not** a continuation of `ha-ai-context-exporter`. It is a clean probe for a different architecture direction:

- native Home Assistant custom integration
- custom sidebar panel UI
- strict read-only design
- GET-only data endpoints
- admin-only access for real Home Assistant data
- privacy-first defaults
- capability-based scope growth

## Current version

`0.2.1`

## Implemented scope

Phase 2 introduces the first real read-only explorer slice:

- Overview
- Entities
- Devices
- Areas
- Integrations
- Relationships

The backend shapes data from Home Assistant readable in-memory sources:

- state machine
- entity registry
- device registry
- area registry
- config entries
- loaded component names

It does not parse Home Assistant storage files, YAML, secrets, or local snapshots.

## API

All real data endpoints are `GET` only and require authenticated Home Assistant admin access:

- `/api/ha_context_explorer_probe/overview`
- `/api/ha_context_explorer_probe/entities`
- `/api/ha_context_explorer_probe/devices`
- `/api/ha_context_explorer_probe/areas`
- `/api/ha_context_explorer_probe/integrations`
- `/api/ha_context_explorer_probe/relationships`

The panel shell is still served in a way that can boot inside the Home Assistant iframe panel. Its HTML is loaded during setup and served from memory to avoid blocking request-handler I/O. Real JSON data is protected separately by Home Assistant auth and an explicit admin check. If the iframe runtime does not provide a compatible auth context for same-origin API requests, the UI shows one clear 401/403 state instead of weakening endpoint auth or repeatedly probing protected endpoints.

## Safety boundaries

The project remains strict read-only:

- no POST / PUT / PATCH / DELETE endpoints
- no service calls
- no state changes
- no restart controls
- no supervisor controls
- no writes to Home Assistant config
- no writes to `.storage`
- no secret access
- no persistent preferences

## Privacy

Responses use mask-first defaults for user-visible strings. Masking currently covers obvious IPv4-like values, MAC-like values, and Wi-Fi / SSID / BSSID contexts where safely detectable.

This masking is best-effort. It is not guaranteed anonymization, and users should still treat exported or copied data with care.

## Future scopes

Future phases may explore floors, labels, dashboards, services, and deeper logic relationships. Those scopes are not implemented in `0.2.1`, and the UI/API should describe them as unavailable or planned rather than pretending support exists.

## Local reference material

The `_local_reference/` directory is ignored and is not repository source of truth. It may be used only as local shaping/reference material while keeping implementation generic for different Home Assistant installations.

Do not copy reference data into repository source files or docs.

## Installation

1. Copy `custom_components/ha_context_explorer_probe` into your Home Assistant `custom_components` directory.
2. Restart Home Assistant.
3. Add the integration from **Settings -> Devices & Services**.
4. Open **Context Explorer Probe** from the sidebar.

## Validation status

See `review_bundle.md` for the focused validation record for this phase. Local validation does not replace testing inside a live Home Assistant runtime.
